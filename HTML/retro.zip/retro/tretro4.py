#El siguiente programa, escribirá los valores de 0 a 20
#Inicializamos una variable en 0
Contador = 0
# Realizamos la comprobación de la condición
while Contador<21:
#Imprimimos el valor de la variable
    print(f"Iteración Número: {Contador}")
    #Incrementamos el valor de la variable
    Contador += 1